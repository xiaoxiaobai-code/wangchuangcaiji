<?php

return array (
  'name' => '我的网站',
  'beian' => '',
  'cdnurl' => '',
  'version' => '1.0.1',
  'timezone' => 'Asia/Shanghai',
  'forbiddenip' => '',
  'languages' => 
  array (
    'backend' => 'zh-cn',
    'frontend' => 'zh-cn',
  ),
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'default' => 'Default',
    'page' => 'Page',
    'article' => 'Article',
    'test' => 'Test',
  ),
  'configgroup' => 
  array (
    'basic' => 'Basic',
    'email' => 'Email',
    'dictionary' => 'Dictionary',
    'user' => 'User',
    'example' => 'Example',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.qq.com',
  'mail_smtp_port' => '465',
  'mail_smtp_user' => '',
  'mail_smtp_pass' => '',
  'mail_verify_type' => '2',
  'mail_from' => '',
  'attachmentcategory' => 
  array (
    'category1' => 'Category1',
    'category2' => 'Category2',
    'custom' => 'Custom',
  ),
  'maopao_cookies' => '_gid=GA1.2.92647433.1739625785; wordpress_test_cookie=WP+Cookie+check; PHPSESSID=d68jv8k2rn0v3vdiro4tvdhbl1; wordpress_logged_in_f2c5d689d02f0686b523970dbb0e3871=57555133%7C1740838164%7CqKJn42fdRQ23rp23LKbFALwyDxkiBj2dhIdYlH3muNj%7Cbb782b92eac56e80d8a803c472bf4ed4782c1087e267fc084963859fb7ff2eb9; wfwaf-authcookie-2bd8c69937dbeb224e95b0bf65e84ae4=4117%7Csubscriber%7Cread%7C3b646297a7dbbdd5e8f8a5e7a7bc26d1819c183e87d9d8e532fe3a096843b163; _gat_gtag_UA_151236324_1=1; _ga_NQYNS8D19N=GS1.1.1739634757.3.1.1739634832.0.0.0; _ga=GA1.1.984311193.1739625785',
  'api_token' => 'qq872672419',
  'zhongchuang_token' => 'qq872672419',
  'zhongchuang_url' => 'https://www.you85.net/',
  'zhongchuang_cookie' => '29i9_2132_it618_loginpreurl=https%3A%2F%2Fwww.you85.net%2F; 29i9_2132_smile=1D1; __51vcke__Jif8tBfRlXqkZFVb=45725eaa-3d08-5a12-8803-7f35d570bdf3; __51vuft__Jif8tBfRlXqkZFVb=1728223619705; 29i9_2132_nofavfid=1; Hm_lvt_1f41814657bb3d6d3a9be69c932d1e38=1727190058,1728223620; __51uvsct__Jif8tBfRlXqkZFVb=7; 29i9_2132_saltkey=XPR8D1Rv; 29i9_2132_lastvisit=1739632969; 29i9_2132_auth=0c180qDYXdUiDqRYSjJw%2F8kcU16prz%2BooE%2FAOnqxKrbNRAVA4gdtBWoI9vDVkHSLjpqQicJmL9IFdf1N%2Fqq4Ur%2B2INA; 29i9_2132_sid=0; 29i9_2132_it618_tbtel=1; 29i9_2132_lastactivity=1; 29i9_2132_visitedfid=70; 29i9_2132_viewid=tid_7988994; 29i9_2132_ulastactivity=1739637590%7C0; 29i9_2132_lastcheckfeed=577135%7C1739637591; 29i9_2132_checkfollow=1; 29i9_2132_checkpm=1; 29i9_2132_sendmail=1; 29i9_2132_lastact=1739637593%09forum.php%09viewthread; 29i9_2132_st_p=577135%7C1739637593%7Cf768a926a2a5b9e39f525b23f404e2f4',
);
