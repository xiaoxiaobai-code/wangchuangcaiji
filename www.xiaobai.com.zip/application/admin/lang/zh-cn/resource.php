<?php

return [
    'Name'       => '资源名称',
    'Content'    => '资源内容',
    'ImgUrl'     => '图片链接',
    'DiskLink'   => '网盘链接',
    'LinkPass'   => '链接密码',
    'Sort'       => '排序',
    'UpdateTime' => '更新时间',
    'CreateTime' => '创建时间'
];
