<?php

return [
    'Card_id'  => '卡密ID',
    'User_id'  => '使用者ID',
    'Use_time' => '使用时间'
];
