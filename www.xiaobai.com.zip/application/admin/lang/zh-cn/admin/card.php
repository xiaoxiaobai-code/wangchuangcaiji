<?php

return [
    'Card_no'        => '卡密号码',
    'Type'           => '卡密类型',
    'Type 1'         => '月卡',
    'Type 2'         => '季卡',
    'Type 3'         => '年卡',
    'Status'         => '使用状态',
    'Status 0'       => '未使用',
    'Set status to 0'=> '设为未使用',
    'Status 1'       => '已使用',
    'Set status to 1'=> '设为已使用',
    'Creator_id'     => '生成者ID',
    'Creator_type'   => '生成者类型',
    'Creator_type 1' => '管理员',
    'Creator_type 2' => '高级代理',
    'Create_time'    => '创建时间',
    'Update_time'    => '更新时间'
];
