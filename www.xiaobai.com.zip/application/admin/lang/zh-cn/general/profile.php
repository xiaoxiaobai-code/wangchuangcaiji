<?php

return [
    'Url'                                         => '链接',
    'Username'                                    => '用户名',
    'Createtime'                                  => '操作时间',
    'Click to edit'                               => '点击编辑',
    'Admin log'                                   => '操作日志',
    'Leave password blank if dont want to change' => '不修改密码请留空',
    'Please input correct email'                  => '请输入正确的Email地址',
    'Please input correct password'               => '密码长度必须在6-30位之间，不能包含空格',
    'Password must be 6 to 30 characters'         => '密码长度必须在6-30位之间，不能包含空格',
    'Email already exists'                        => '邮箱已经存在',
];
