<?php

return [
    'maopao_cookies'        => '冒泡网站Cookies',
    'maopao_cookies_tips'   => '采集程序使用的Cookies值'
]; 