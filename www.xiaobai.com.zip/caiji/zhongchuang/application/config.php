// 开启多语言支持
'lang_switch_on' => true,
'lang_list' => ['zh-cn','en'],
'default_lang' => 'zh-cn', 