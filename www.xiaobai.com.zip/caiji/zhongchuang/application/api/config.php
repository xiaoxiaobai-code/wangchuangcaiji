<?php

return [
    // API接口默认返回格式
    'default_return_type' => 'json',
    
    // 异常处理handle类
    'exception_handle'    => '\\app\\api\\library\\ExceptionHandle',
]; 